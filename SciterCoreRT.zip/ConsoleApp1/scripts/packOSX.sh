#!/bin/sh

chmod +x scripts/packfolder
scripts/packfolder res ArchiveResource.cs -csharp